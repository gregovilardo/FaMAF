#include <stdbool.h>
#include <assert.h>

#include "fixstring.h"

unsigned int fstring_length(fixstring s) {
    /*
     * COMPLETAR
     *
     */
}

bool fstring_eq(fixstring s1, fixstring s2) {
    /*
     * COMPLETAR
     *
     */
}

bool fstring_less_eq(fixstring s1, fixstring s2) {
    /*
     * COMPLETAR
     *
     */
}

