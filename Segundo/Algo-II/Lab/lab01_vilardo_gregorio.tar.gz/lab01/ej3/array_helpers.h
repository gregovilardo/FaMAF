unsigned int array_from_file(int[] , unsigned int , const char*);
void array_dump(int[], unsigned int);
bool array_is_sorted(int[], unsigned int);

