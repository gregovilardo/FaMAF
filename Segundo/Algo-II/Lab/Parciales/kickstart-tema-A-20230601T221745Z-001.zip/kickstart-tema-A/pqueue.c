#include <stdlib.h>
#include <assert.h>
#include <stdbool.h>
#include "pqueue.h"

struct s_pqueue
{
    unsigned int size;
    struct s_node *front;
};

struct s_node
{
    pqueue_elem elem;
    float average_grade;
    unsigned int approved_courses;
    float priority;
    struct s_node *next;
};


static float calculate_priority(float average_grade,
                                unsigned int approved_courses)
{
    float priority = 0;
    priority = 0.5 * (average_grade/MAX_GRADE) + 0.5 * (approved_courses/TOTAL_COURSES);
    return priority;
}

static struct s_node *create_node(pqueue_elem e,
                                  float average_grade,
                                  unsigned int approved_courses)
{

    struct s_node *new_node = NULL;
    float priority = calculate_priority(average_grade, approved_courses);

    new_node = malloc(sizeof(struct s_node));

    assert(new_node != NULL);

    new_node->elem = e;
    new_node->average_grade = average_grade;
    new_node->approved_courses = approved_courses;

    new_node->priority = priority;

    new_node->next = NULL;

    return new_node;
}

static struct s_node *destroy_node(struct s_node *node)
{
    assert(node != NULL);

    free(node);
    node = NULL;

    assert(node == NULL);
    return node;
}

static bool invrep(pqueue q)
{
    bool b = true;
    if (q != NULL && q->size != 0) {
        struct s_node *temp = q->front;
        while (temp->next != NULL) {
            if (temp->priority < temp->next->priority) {
                b = false;
            }
            temp = temp->next;
        }
    }
    return b;
}

pqueue pqueue_empty(void)
{
    pqueue q = NULL;

    q = malloc(sizeof(struct s_pqueue));
    q->size = 0;
    q->front = NULL;

    return q;
}

pqueue pqueue_enqueue(pqueue q,
                      pqueue_elem e,
                      float average_grade,
                      unsigned int approved_courses)
{
    assert(invrep(q));
    struct s_node *new_node = create_node(e, average_grade, approved_courses);
    
    if (q->size == 0){
        q->front = new_node;
        (q->size)++;
    }
    else
    {
        struct s_node *temp = q->front;
        if (temp->priority < new_node->priority)
        {
            new_node->next = temp;
            q->front = new_node;
        }
        else
        {
            while (temp->next != NULL && temp->next->priority >= new_node->priority){
                temp = temp->next;
            }
            new_node->next = temp->next;
            temp->next = new_node;
        }
        (q->size)++;
    }

    assert(invrep(q) && !pqueue_is_empty(q));
    return q;
}

bool pqueue_is_empty(pqueue q)
{
    return (q->size == 0);
}


pqueue_elem pqueue_peek(pqueue q)
{
    assert(invrep(q) && !pqueue_is_empty(q));
    return q->front->elem;
}

float pqueue_peek_average_grade(pqueue q)
{
    assert(invrep(q));
    float avgrade = q->front->average_grade;
    assert(invrep(q));
    return avgrade;
}

unsigned int pqueue_peek_approved_courses(pqueue q)
{
    assert(invrep(q));
    unsigned int apcourse = q->front->approved_courses;
    assert(invrep(q));
    return apcourse;
}

float pqueue_peek_priority(pqueue q)
{
    assert(invrep(q));
    float prio = q->front->priority;
    assert(invrep(q));
    return prio;
}

unsigned int pqueue_size(pqueue q)
{
    assert(invrep(q));
    unsigned int size = 0;
    size = q->size;
    assert(invrep(q));
    return size;
}

pqueue pqueue_copy(pqueue q)
{
    assert(invrep(q));

    pqueue copy = malloc(sizeof(struct s_pqueue));
    copy = q;

    return copy;
}

pqueue pqueue_dequeue(pqueue q)
{
    assert(invrep(q));

    assert(!pqueue_is_empty(q));
    struct s_node *p = q->front;
    q->front = q->front->next;
    (q->size)--;
    destroy_node(p);
    p = NULL;
    assert(invrep(q));
    return q;
}

pqueue pqueue_destroy(pqueue q)
{
    if (pqueue_is_empty(q)) 
    {
        free(q);
        q = NULL;
    } else 
    {
        // Necesito llevar 2 punteros, 1 para determinar los nodos siquientes
        // el otro para liberarlos
        struct s_node *p = q->front;
        struct s_node *aux;
        while (p->next != NULL)
        {
            aux = p;
            p = p->next;
            destroy_node(aux);
        }
        destroy_node(p);
        p = NULL;
        free(q);
        q = NULL;
    }
    assert(q == NULL);

    return q;
}
